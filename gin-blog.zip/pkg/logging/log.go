package logging

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
)

type Level int

var (
	F *os.File

	DefaultPrefix      = ""
	DefaultCallerDepth = 2

	logger     *log.Logger
	logPrefix  = ""
	levelFlags = []string{"DEBUG", "INFO", "WARN", "ERROR", "FATAL"}
)

const (
	DEBUG Level = iota
	INFO
	WARNING
	ERROR
	FATAL
)

func Setup() {
	var err error
	filePath := getLogFilePath()
	fileName := getLogFileName()
	F, err = openLogFile(fileName, filePath)
	if err != nil {
		log.Fatalln(err)
	}

	fmt.Println("come here log SetUp", filePath)
	logger = log.New(F, DefaultPrefix, log.LstdFlags)
}

func Debug(v ...interface{}) {
	setPrefix(DEBUG)
	logger.Println(v...)
}

func Info(v ...interface{}) {
	setPrefix(INFO)
	fmt.Println("log info execute")
	logger.Println(v...)
}

func Warn(v ...interface{}) {
	setPrefix(WARNING)
	logger.Println(v...)
}

func Error(v ...interface{}) {
	setPrefix(ERROR)
	logger.Println(v...)
}

func Fatal(v ...interface{}) {
	setPrefix(FATAL)
	logger.Println(v...)
}

func setPrefix(level Level) {
	fmt.Println("come here 0000")
	_, file, line, ok := runtime.Caller(DefaultCallerDepth)
	fmt.Println("come here first", file, line)
	if ok {
		logPrefix = fmt.Sprintf("[%s] [%s:%d]", levelFlags[level], filepath.Base(file), line)
		fmt.Println("come here ok", logPrefix)
	} else {
		logPrefix = fmt.Sprintf("[%s]", levelFlags[level])
		fmt.Println("come here not ok", logPrefix)
	}
	logger.SetPrefix(logPrefix)
}
